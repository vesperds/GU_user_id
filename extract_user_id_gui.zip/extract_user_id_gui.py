import os
import re
import tkinter as tk

def extract_user_id():
    # Construct the file path with the user profile directory
    file_path = os.path.expandvars(r"%userprofile%\AppData\LocalLow\Immutable\gods\Player.log")

    # Open the file in read mode
    with open(file_path, 'r') as file:
        # Read the contents of the file
        file_content = file.read()

    # Use regular expression to find the user_id value
    match = re.search(r'user_id:\s*(\d+)', file_content)
    if match:
        user_id = match.group(1)
        result_label.config(text="user_id: " + user_id)
    else:
        result_label.config(text="user_id not found in the file.")

# Create a GUI window
window = tk.Tk()
window.title("User ID Extractor")

# Create a label to display the result
result_label = tk.Label(window, text="")
result_label.pack(pady=10)

# Create a button to extract the user_id
extract_button = tk.Button(window, text="Extract user_id", command=extract_user_id)
extract_button.pack(pady=5)

# Run the GUI event loop
window.mainloop()